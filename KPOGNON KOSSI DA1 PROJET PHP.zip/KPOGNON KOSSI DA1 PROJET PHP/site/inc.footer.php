</main>
<footer>
    <p>All right reserved</p>
    <script>
        <?php include("script.js") ?>
    </script>
</footer>
</body>

</html>